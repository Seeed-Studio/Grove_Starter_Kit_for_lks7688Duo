#!/usr/bin/node

console.log('Begin...');

require('events').EventEmitter.defaultMaxListeners = Infinity;
var mcs = require('mcsjs');

var myApp = mcs.register({
    deviceId: 'DKNgeOMx',
    deviceKey: 'SEq5etVEwutJ0hnA',
});
// Replace the device ID and device Key obtained from your test device
// created in MCS.
myApp.on('switch', function(time, data) {
    var fs = require('fs');
    console.log('switch: ' + data);
    fs.open('/tmp/mcs_data', 'a+', function(err, fd){
        if(err != null){
            console.log(err);            
        }
        fs.writeFile('/tmp/mcs_data', data, function(err){
            if(err != null){
                return console.log(err);
            }
        });
    });
});