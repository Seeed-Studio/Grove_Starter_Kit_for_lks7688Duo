#!/usr/bin/python

DATA=$1

curl -X POST -H "deviceKey: SEq5etVEwutJ0hnA" -H "Cache-Control: no-cache" -H "Content-Type: text/csv" -H "Connection: close" -d "light_sensor,,${DATA}" 'http://api.mediatek.com/mcs/v2/devices/DKNgeOMx/datapoints.csv'    
    